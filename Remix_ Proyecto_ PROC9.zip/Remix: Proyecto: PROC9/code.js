var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["c4e310e0-8174-4127-a46e-0cbcc94b488b","6d0f38f2-93c1-4680-97c5-410cb2f8b366","c6e17c7d-7b06-4721-abbc-fd4c44b0660c","c7a569c8-3035-4788-b7ab-482915addf13","83f15bc6-3f8c-40c9-8224-adbc22ad7f7c","8608d5b3-541d-4476-85f4-240519943f25","41154293-25e0-416b-b6fc-ab48ae2d294d","f6e082b1-1815-4ced-8e0d-7c93a0613b73"],"propsByKey":{"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"_F9M3WxnnvUkGu8aKyOffD7Kcu7hbkCw","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"6d0f38f2-93c1-4680-97c5-410cb2f8b366":{"name":"hero1","sourceUrl":"assets/api/v1/animation-library/gamelab/Y8rLrPP4qJ_PtGUAXmnx3fkbeEisuyxJ/category_animals/butterfly.png","frameSize":{"x":393,"y":257},"frameCount":1,"looping":true,"frameDelay":3,"version":"Y8rLrPP4qJ_PtGUAXmnx3fkbeEisuyxJ","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":257},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Y8rLrPP4qJ_PtGUAXmnx3fkbeEisuyxJ/category_animals/butterfly.png"},"c6e17c7d-7b06-4721-abbc-fd4c44b0660c":{"name":"enemy","sourceUrl":"assets/v3/animations/eC2eUctTG5YNlXO0uU2DfJqLqPmk0y-5upVCSC5bnZU/c6e17c7d-7b06-4721-abbc-fd4c44b0660c.png","frameSize":{"x":198,"y":255},"frameCount":1,"looping":true,"frameDelay":4,"version":"84p3GdZjx9C26Q89kO8XSMXLKsFNLNgX","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":198,"y":255},"rootRelativePath":"assets/v3/animations/eC2eUctTG5YNlXO0uU2DfJqLqPmk0y-5upVCSC5bnZU/c6e17c7d-7b06-4721-abbc-fd4c44b0660c.png"},"c7a569c8-3035-4788-b7ab-482915addf13":{"name":"enemy2","sourceUrl":"assets/v3/animations/eC2eUctTG5YNlXO0uU2DfJqLqPmk0y-5upVCSC5bnZU/c6e17c7d-7b06-4721-abbc-fd4c44b0660c.png","frameSize":{"x":198,"y":255},"frameCount":1,"looping":true,"frameDelay":4,"version":"84p3GdZjx9C26Q89kO8XSMXLKsFNLNgX","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":198,"y":255},"rootRelativePath":"assets/v3/animations/eC2eUctTG5YNlXO0uU2DfJqLqPmk0y-5upVCSC5bnZU/c6e17c7d-7b06-4721-abbc-fd4c44b0660c.png"},"83f15bc6-3f8c-40c9-8224-adbc22ad7f7c":{"name":"enemy3","sourceUrl":"assets/v3/animations/eC2eUctTG5YNlXO0uU2DfJqLqPmk0y-5upVCSC5bnZU/c6e17c7d-7b06-4721-abbc-fd4c44b0660c.png","frameSize":{"x":198,"y":255},"frameCount":1,"looping":true,"frameDelay":4,"version":"84p3GdZjx9C26Q89kO8XSMXLKsFNLNgX","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":198,"y":255},"rootRelativePath":"assets/v3/animations/eC2eUctTG5YNlXO0uU2DfJqLqPmk0y-5upVCSC5bnZU/c6e17c7d-7b06-4721-abbc-fd4c44b0660c.png"},"8608d5b3-541d-4476-85f4-240519943f25":{"name":"b2","sourceUrl":"assets/api/v1/animation-library/gamelab/B7nUqE7MHvtM.bH.nFWaMiZcfScwjIfx/category_backgrounds/farm_land.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"B7nUqE7MHvtM.bH.nFWaMiZcfScwjIfx","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/B7nUqE7MHvtM.bH.nFWaMiZcfScwjIfx/category_backgrounds/farm_land.png"},"41154293-25e0-416b-b6fc-ab48ae2d294d":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/2JbYx3k.w.ZsY_IjFwTPssGZWs1Pv25./category_backgrounds/background_rainbow.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"2JbYx3k.w.ZsY_IjFwTPssGZWs1Pv25.","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/2JbYx3k.w.ZsY_IjFwTPssGZWs1Pv25./category_backgrounds/background_rainbow.png"},"f6e082b1-1815-4ced-8e0d-7c93a0613b73":{"name":"flower_1","sourceUrl":"assets/api/v1/animation-library/gamelab/QK5UiR3Ac1WgRhwaCsIB1UfnbUhSQhcW/category_video_games/flower.png","frameSize":{"x":336,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"QK5UiR3Ac1WgRhwaCsIB1UfnbUhSQhcW","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":336,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/QK5UiR3Ac1WgRhwaCsIB1UfnbUhSQhcW/category_video_games/flower.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var b = createSprite(200,200);
 b.setAnimation("b");
var hero = createSprite(200,345,200,345);
hero.shapeColor="red";

var enemy1 = createSprite(200,250,10,10);
enemy1.shapeColor="red";

var enemy2 = createSprite(200,150,10,10);
enemy2.shapeColor="red";

var enemy3 = createSprite(200,50,10,10);
enemy3.shapeColor="red";

var net = createSprite(200,5,200,20);
net.shapeColor="red";

var goal =0;
var death = 5;

hero.setAnimation("hero1");
hero.scale=0.1;
enemy1.setAnimation("enemy");
enemy1.scale=0.2;
enemy2.setAnimation("enemy2");
enemy2.scale=0.2;
enemy3.setAnimation("enemy3");
enemy3.scale=0.2;

net.setAnimation("dream");
net.scale=0.2;

enemy1.setVelocity(-10,0);
enemy2.setVelocity(10,0);
enemy3.setVelocity(-10,0);


function draw() {
  
  textSize(20);
  fill("blue");
  text("Goals:"+goal,320,350);
  
 text("death:"+death,20,350);
textSize(20);
  fill("black");
//fondo(b);

createEdgeSprites();




enemy1.bounceOff(edges);
enemy2.bounceOff(edges);
enemy3.bounceOff(edges);

if(keyDown(UP_ARROW)){
  hero.y=hero.y-5;
}

if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+5;
}

if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-5;
}

if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+5;
}

if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3)){
  playSound("assets/category_app/app_button_1.mp3");
  hero.x=200;
  hero.y=350;
  death = death-1;
}
if(hero.isTouching(net)){
  playSound("assets/category_alerts/vibrant_game_carton_start_game_2_long.mp3");
  hero.x=200;
  hero.y=345;
  goal=goal+1;
}

  

  
drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
